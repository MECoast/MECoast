SCOT SOUNDS
~~~~~~~~~~~~
~~~~~~~~~~~~



1. WHISTLE

Constructed by Dave Bran from an old cine recording using the excellent "Audacity" Windows sound system.

Copy the single .wav file to common.sound\uk_shared. It is uniquely named so should not overwrite anything.

2. OTHER SOUNDS

Uses Stuart Willaimson's sound system files with his permission, modified by Dave Bran

The two .sms files should be copied to common.sound\3cyl_generic.

They are numbered "99" and so should not overwrite anything.


Thanks to Stuart Williamson for generating the base Freeware files which truly represent the British Locomotive.

RESPECT FREEWARE COPYRIGHT - these files are NOT to be sold or distributed without the express written permission of the author.

Dave Bran
bravedan@tinyonline.co.uk